<script src=rutina.js></script>
<input type="button" name="n" value="subir" onclick="slidedown('mydiv');">
<div id="mydiv" style="position:relative;top:31px;left:237px;background-color:white;display:none; overflow:hidden; height:400px;overflow:auto;border:solid;">
hhiijiiiiiiiiiiiiiiiiiiiiiiiiii
</div>