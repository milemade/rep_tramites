<?php session_start();
 require_once("conf/clave.php");
//print_r($_SESSION);
 //require_once("tiemposesion.php");
 ?>
 <?php
   if(isset($_POST['n']) && $_POST['n']>0)
        $n = $_POST['n'];
   if(isset($_GET['n']) && $_GET['n']>0)
        $n = $_GET['n'];
   if(isset($_POST['mio']) && $_POST['mio']>0)
        $mio = $_POST['mio'];
   if(isset($_POST['b']) && $_POST['b']>0)
        $b = $_POST['b']; 
    if($_GET['id']>0)
	   $_POST['id'] = $_GET['id'];
  // print_r($_POST); 
  /////////
  
?>
<?php
/* PARA CAPTURAR INFORMACION EQUIPO
if($_SERVER["HTTP_X_FORWARDED_FOR"]){
echo "La Ip de tu proxy es:{$_SERVER["REMOTE_ADDR"]}<br>";
echo "Tu IP es:{$_SERVER["HTTP_X_FORWARDED_FOR"]}";
}else{
echo "NO HAY PROXY<BR>";
echo "Tu IPyy es:{$_SERVER["REMOTE_ADDR"]}<br>";
////////////NOMBRE EQUIPO INTRANET///////////////////////
$hostname = explode(".", gethostbyaddr($_SERVER['REMOTE_ADDR']));
echo "NOMBRE EQUIPO remoteaddrr: ".$hostname[0]; 
echo "<br>"; 
echo PHP_uname('a');		
				
}*/

?> 

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml2/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?=$nombre_aplicacion?></title>
<script language="javascript" type="text/javascript" src="kalendar/jquery-1.7.1.min.js"></script>
<script language="javascript" type="text/javascript" src="kalendar/jquery.kalendar.min.js"></script>
<script type="text/javascript" src="reveal/jquery.reveal.js"></script>
<script language="javascript" type="text/javascript">
	$(document).ready(function(){
		$(".test").kalendar();
	});
</script>
<link rel="stylesheet" href="kalendar/kalendar.css" type="text/css" media="screen" />
<link rel="stylesheet" type="text/css" href="tabbed_pages/interna_pages.css" />
<link rel="stylesheet" type="text/css" href="acordeon.css" />
<link rel="stylesheet" href="reveal/reveal.css">
<link href="tools.css" rel="stylesheet" type="text/css" />
<link href='imagenes/loguito.png' rel='shortcut icon' type='image/x-icon'/>
<link href='imagenes/loguito.png' rel='icon' type='image/x-icon'/> 
<SCRIPT LANGUAGE="JavaScript">
function validarnumero(e) { // 1
    tecla = (document.all) ? e.keyCode : e.which; // 2
    if (tecla==8) return true; // 3
    //patron =/[A-Za-z\s]/; // 4
    patron = /\d/; // Solo acepta numeros
    //patron = /\w/; // Acepta numeros y letras
    //patron = /\D/; // No acepta numeros
    //patron =/[A-Za-z��\s]/; // igual que el ejemplo, pero acepta tambien las letras � y �
    //patron = /[ajt69]/;
    te = String.fromCharCode(tecla); // 5
    return patron.test(te); // 6
} 
</script>
<script type="text/javascript"> 
/*FUNCION PARA TABULAR*/           
function handleEnter (field, event) {
	var keyCode = event.keyCode ? event.keyCode : event.which ? event.which : event.charCode;		if (keyCode == 13) {
		var i;
		for (i = 0; i < field.form.elements.length; i++)
			if (field == field.form.elements[i])
				break;
		i = (i + 1) % field.form.elements.length;
		field.form.elements[i].focus();
		return false;
	}
 	else
	return true;}
</script>
<style>
a.Ntooltip {
position: relative; /* es la posici�n normal */
text-decoration: none !important; /* forzar sin subrayado */
color:#0080C0 !important; /* forzar color del texto */
font-weight:normal !important; /* forzar negritas */
font-size: 12px;
}

a.Ntooltip:hover {
z-index:999 !important;  /* va a estar por encima de todo */
/*background-color:#fff !important;  DEBE haber un color de fondo */
}

a.Ntooltip span {
display: none; /* el elemento va a estar oculto */
}

a.Ntooltip:hover span {
display: table-caption; /* se fuerza a mostrar el bloque */
position: absolute; /* se fuerza a que se ubique en un lugar de la pantalla */
//top:2em; left:2em; /* donde va a estar */
width:450px; /* el ancho por defecto que va a tener */
padding:5px; /* la separaci�n entre el contenido y los bordes */
background-color: #0080C0; /* el color de fondo por defecto */
color: #FFFFFF; /* el color de los textos por defecto */
}
</style>
<script> function cambiarDisplay(id) {
  if (!document.getElementById) return false;
  fila = document.getElementById(id);
  if (fila.style.display != "none") {
    fila.style.display = "none"; //ocultar fila
  } else {
    fila.style.display = ""; //mostrar fila
  }
} </script>
<script type="text/javascript" language="javascript" src="easytabs.js"></script>
</head>
<body onload="if(document.frm.txt_quin2.value==0) document.frm.txt_quin2.value='';if(document.frm.txt_quin1.value==0) document.frm.txt_quin1.value='';">
<div id="cuerpo_int">

<div class="logo">

<a href="index.php"><img src="imagenes/logo_centro_int.png" alt="Centro de Soluciones" width="428" height="76" class="left" /></a>

<div id="usuario"><h2 class="txt_azul"><?php if($_SESSION['exc_id']>0) echo $Gen->GetUnDato("exc_nombre","SELECT exc_nombre FROM empresa_cliente WHERE exc_id=".$_SESSION['exc_id']." AND exc_estado=1;");?>  <?php if($_SESSION['usu_nombre']!="") echo $_SESSION['usu_nombre'];?></h2>
</div>

<br class="clear" />
</div>

<!--AQUI COMIENZA-->
<?php if($n==1) {

   require_once("menu.php");
}  
if($n==11) 
{
   require_once("registrese.php"); 
} 
if($n==12) {
    require_once("olvidopassword.php"); 
} ?>
<?php
   if($n==121)
   {
        require_once("enviopassword.php");
   }
?>
<?php
   if($n==2)
   {
       require_once("buscartramite.php");
   }
?>
<?php
   if($n==3)
   { 
      require_once("configuracion.php");
	  //require_once("cargar/index.html");
   }
?>

<?php
   if($n==4)
   { 
      unset($_SESSION['consecutivo']);
	  unset($_SESSION['departamento']);
	  unset($_SESSION['ciudad']);  
	  require_once("tramites.php");
   }
?>
<?php
  if($n==41)
  { //GUARDA EL TRAMITE
       $Valorestramite = "tra_ciu_id|N,tra_axe_id|N,tra_txt_id|N,tra_nombre|S,tra_cxt_id|N,tra_txo_id|N,tra_prioridad|N,
                          tra_observaciones|S,tra_usu_id|N,tra_equipo|S,tra_ext_id|N";  
       $idnew = $Gen->SetValores($Valorestramite,"tramite"); 
       $consecutivo = $Tra->consecutivo($_POST['tra_axe_id']); 
	   $Gen->logueado($_SESSION['usu_id'],$_SESSION['equipo'],"Ingreso tramite".$consecutivo);
       $sqlcon = "UPDATE tramite SET tra_consecutivo='".$consecutivo."' WHERE tra_id=".$idnew.";"; 
       $Gen->updatesql($sqlcon);
       if($_POST['txr_usuasig']>0 && $_POST['txr_observaciones']!="")
       { //Si hay usuario asignado y hay observaciones de la asignacion Guarda en tramite_observaciones  
	      //echo "ENTRE"; //exit;
          $_POST['txo_tra_id'] = $idnew;
		  $_POST['txo_observaciones'] = $_POST['txr_observaciones'];
	      $ValoresAsig = "txo_tra_id|N,txo_usu_id|N,txo_observaciones|S";
	      $uu = $Gen->SetValores($ValoresAsig,"tramite_observaciones");//exit;
	      //Se cambia estado tramite
		  if($uu>0)
		  {
	         $sql = "UPDATE tramite SET tra_ext_id=7,tra_car_id=".$_POST['txr_usuasig']." WHERE tra_id=".$idnew.";";; 
	         $Gen->updatesql($sql);
	         $_POST['txr_tra_id'] = $idnew;
	         $Valoresasignacion = "txr_tra_id|N,txr_usuasig|N,txr_usuinicial|N,txr_observaciones|N";
	         $Gen->SetValores($Valoresasignacion,"tramite_reasignacion"); //
		  }
       }
      ?>
      <form name="form" action="aplicacion.php" method="POST">
      <input type="hidden" name="id" value="<?=$idnew?>">
	  <?php $sqlcon = "SELECT tra_consecutivo FROM tramites WHERE tra_id=".$idnew.";";?>
	  <input type="hidden" name="consecutivo" value="<?=$Gen->GetUnDato("tra_consecutivo",$sqlcon)?>">
      <input type="hidden" name="n" value="4">
	  <input type="hidden" name="msg" value="Registro Guardado satisfactoriamnte!">
      </form>
      <script>document.form.submit();</script>
<?php      
 exit; }
?>
<?php if($n==42){ //Edita el tramite en pantalla
      $Valorestramite = "tra_ciu_id|N,tra_axe_id|N,tra_txt_id|N,tra_nombre|S,tra_cxt_id|N,tra_txo_id|N,
	                     tra_prioridad|N,tra_observaciones|S,tra_usu_id|N,tra_equipo|S,tra_ext_id|N"; 
	  $Gen->SetDatos($Valorestramite,"tramite","tra_id=".$_POST['idedi']);
	  $Gen->logueado($_SESSION['usu_id'],$_SESSION['equipo'],"Modifico tramite".$_POST['tra_consecutivo']);
	  if($_POST['txr_usuasig']>0 && $_POST['txr_observaciones']!="")
       { //Si hay usuario asignado y hay observaciones de la asignacion Guarda en tramite_observaciones   tramite_reasignacion
	      $_POST['txo_tra_id']= $_POST['idedi'];
		  $_POST['txo_observaciones'] = $_POST['txr_observaciones'];
	      $ValoresAsig = "txo_tra_id|N,txo_usu_id|N,txo_observaciones|S";
	      $uu = $Gen->SetValores($ValoresAsig,"tramite_observaciones");
		  $_POST['txr_tra_id'] =$_POST['idedi'];
	      $valoresreasignacion = "txr_tra_id|N,txr_usuasig|N,txr_usuinicial|N,txr_observaciones|N";
	      $Gen->SetValores($valoresreasignacion,"tramite_reasignacion");
		  $sql = "UPDATE tramite SET tra_ext_id=7,tra_car_id=".$_POST['txr_usuasig']." WHERE tra_id=".$_POST['idedi'].";";; 
	      $Gen->updatesql($sql);
		  $Gen->logueado($_SESSION['usu_id'],$_SESSION['equipo'],"Modifico Reasignacion tramite: ".$_POST['tra_consecutivo']);
	  }
?>
 <form name="form" action="aplicacion.php" method="POST">
      <input type="text" name="id" value="<?=$_POST['idedi']?>">
	  <input type="hidden" name="n" value="4">
	  <input type="hidden" name="msg" value="Registro Modificado satisfactoriamente!">
      </form>
      <script>document.form.submit();</script>
<?php      
 exit; }
?>
<?php 
     if($n==433){ // Agregar Documento Principal 
        $Valores = "doc_tra_id|N,doc_ciu_id|N,doc_txd_id|N,doc_usudestinoid|N,doc_usudestino|S,doc_axe_id|N,doc_exc_id|N,
		            doc_entremitente|S,doc_remitente|S,doc_usu_id|N,doc_equipo|S,
		            doc_fecdoc|S,doc_asunto|S,doc_obsdocmento|S,doc_anexos|S,doc_txe_id|N";
        $iddoc = $Gen->SetValores($Valores,"documento");
		$Gen->logueado($_SESSION['usu_id'],$_SESSION['equipo'],"Ingreso Documento tramite".$_POST['tra_consecutivo']); 
		if($iddoc>0)
		{
		   $mesg =  "Registro Almacenado Satisfactoriamente";
		 ?>
	<form name="frrm" action="aplicacion.php" method="post">
	<input type="hidden" name="n" value="4">
	<input type="hidden" name="id" value="<?=$_POST['doc_tra_id']?>">
	<input type="hidden" name="iddoc" value="<?=$iddoc?>">
	<input type="hidden" name="msg" value="<?=$msg?>">
	</form>
	<script>document.frrm.submit();</script>
<?php exit;} } ?>
<?php if($n==44){//Edita Carga Documento Principal
     $Valoresdoc = "doc_tra_id|N,doc_ciu_id|N,doc_txd_id|N,doc_usudestinoid|N,doc_usudestino|S,doc_axe_id|N,doc_exc_id|N,
		            doc_entremitente|S,doc_remitente|S,doc_usu_id|N,doc_equipo|S,
		            doc_fecdoc|S,doc_asunto|S,doc_obsdocmento|S,doc_anexos|S,doc_txe_id|N"; 
	 $banupd = $Gen->SetDatos($Valoresdoc,"documento","doc_id=".$_POST['iddocu']);
	 if($banupd>0) $msg = "Registro Modificado Satisfactoriamente.";
	 $Gen->logueado($_SESSION['usu_id'],$_SESSION['equipo'],"Modifica Documento tramite".$_POST['tra_consecutivo']); 
?>
<form name="frrm" action="aplicacion.php" method="post" >
	<input type="hidden" name="n" value="4">
	<input type="hidden" name="id" value="<?=$_POST['doc_tra_id']?>">
	<input type="hidden" name="iddoc" value="<?=$_POST['iddocu']?>">
	<input type="hidden" name="msg" value="<?=$msg?>">
	</form>
	<script>document.frrm.submit();</script>
<?php exit; } ?>
<?php  
      if($n==45)
	  { //Carga archivo documentos
	     $directoriotramite = $path_documentos.$_POST['consecutivo'];
		 if(!is_dir($directoriotramite))//Si no existe, lo crea
		 {
	         $result = mkdir($directoriotramite, 0755);
		      //print_r($HTTP_POST_FILES);
              if ($result == 1) {
                  //echo $dirPath . " has been created".$_POST['consecutivo'];
			      $totalarchivos = count($HTTP_POST_FILES);	
                  for($i=1;$i<$totalarchivos;$i++)	
			      {   
			         $arch = "file_".$i;
					 $nombre = "nombre_".$i;
					 $comen = "comen_".$i;
				     $archivo = $_FILES[$arch]['name'];
					 //echo "<br>";
					 $tipo = $_FILES[$arch]['type'];
					 //echo "<br>";
					 if($tipo!="application/octet-stream")
					 {
				        if (copy($_FILES[$arch]['tmp_name'],$directoriotramite."/".$archivo)) {
			               echo $status = "Archivo subido: <b>".$archivo."</b>";
						$Tra->guardarfiles($_POST['dxt_tra_id'],$_POST[$nombre],$archivo,$_POST[$comen],$_POST['dxt_equipo'],$_POST['dxt_usu_id']);
		              } else {
			                 echo $status = "Error al subir el archivo".$archivo;
		              }
					}
			     }			  
			 } 
         } else 
		 {
              //$dirPath . " No se creo el directorio.";
			  $totalarchivos = count($HTTP_POST_FILES);	
              for($i=1;$i<=$totalarchivos;$i++)	
			  {
			         $arch = "arch_".$i;
					 $nombre = "nom_".$i;
					 $comen = "comen_".$i;
					 $archivo = $_FILES[$arch]['name'];
					 $tipo = $_FILES[$arch]['type'];
					 if($tipo!="application/octet-stream")
					 {
					 if (copy($_FILES[$arch]['tmp_name'],$directoriotramite."/".$archivo)) {
			            echo $status = "Archivo subido: <b>".$archivo."</b>";
						$Tra->guardarfiles($_POST['dxt_tra_id'],$_POST[$nombre],$archivo,$_POST[$comen],$_POST['dxt_equipo'],$_POST['dxt_usu_id']);
		              } else {
			                 echo $status = "Error al subir el archivo";
		              }
				     }
              }
		$consec = $Gen->GetUnDato("tra_consecutivo","SELECT tra_consecutivo FROM tramite WHERE tra_id=".$_POST['id']);	  
     $Gen->logueado($_SESSION['usu_id'],$_SESSION['equipo'],"Carga Documentos tramite ".$consec); 			  
         } ?>
		 <form name="ffrm" action="aplicacion.php" method="post">
		 <input type="hidden" name="n" value="4">
		 <input type="hidden" name="id" value="<?=$_POST['dxt_tra_id']?>">
		 <input type="hidden" name="iddoc" value="<?=$_POST['iddoc']?>">
		 <input type="hidden" name="directorio" value="<?=$directoriotramite?>">
		 </form>
		 <script>document.ffrm.submit();</script>
	<?php exit;  } ?>
	<?php if($n==46){ 
	           $ValoresObs = "txo_reales|S,txo_observaciones|S,txo_ext_id|N,txo_tra_id|N,txo_ip|S,txo_usu_id|N";
			   $id_tabla = $Gen->SetValores($ValoresObs,$t_tramite_observaciones);
			   $Gen->SetDatos("tra_ext_id|N","tramite","tra_id=".$_POST['dxt_tra_id']); //actualiza estado si lo cambia
			   $consec = $Gen->GetUnDato("tra_consecutivo","SELECT tra_consecutivo FROM ".$t_tramite." WHERE tra_id=".$_POST['dxt_tra_id']);
			   $Gen->logueado($_SESSION['usu_id'],$_SESSION['equipo'],"Apuntaron observaciones tramite ".$consec); 			  
	?>
	<form name="fform" action="aplicacion.php" method="post">
		 <input type="hidden" name="n" value="4">
		 <input type="hidden" name="id" value="<?=$_POST['id']?>">
		 <input type="hidden" name="iddoc" value="<?=$_POST['iddoc']?>">
		 </form>
	<script>document.fform.submit();</script> 
	<?php exit;  } ?>
	<?php if($n==47)
	{  
	   $sqlt = "SELECT a.tra_id, b.doc_id FROM tramite a LEFT JOIN documento b ON a.tra_id=b.doc_tra_id WHERE tra_consecutivo='".$_POST['codigotra']."';";
	   //echo $sqlt; exit;
	   $dbt = new Database();
	   $dbt->query($sqlt);
	   $dbt->next_row();
	   $idtra = $dbt->tra_id;
	   $iddoc = $dbt->doc_id;
	   $dbt->close(); ?>  
	<form name="form" method="POST" action="aplicacion.php">
	<input type="hidden" name="n" value="4">
	<input type="hidden" name="id" value="<?=$idtra?>">
	<input type="hidden" name="iddoc" value="<?=$iddoc?>">
  	</form>
	<script>document.form.submit();</script>
<?php	exit;}
	?>
<?php 
  if($n==51)
  { //Nuevos Usuarios
     $campos = "usu_nombre|S,usu_apel|S,usu_corto|S,usu_cedula|S,usu_car_id|N,usu_emailcor|S,usu_emailper|S,usu_fijo|S,";
     $campos .= "usu_celular|S,usu_dir|S,usu_obs|S,usu_act_id|S,usu_per_id|N";
     $Gen->SetValores($campos,"usuario");
     $Gen->AsignarDatos($_POST['usu_cedula'],$_POST['usu_emailcor'],$_POST['usu_emailper'],$mailadministrador);
     $Gen->logueado($_SESSION['usu_id'],$_SESSION['equipo'],"Ingresar Usuarios");
     ?>
     <form name="frmenv" action="aplicacion.php" method="POST">
     <input type="hidden" name="n" value="5">
     <input type="hidden" name="msg" value="Usuario ingresado con exito!">
     </form>
     <script>document.frmenv.submit();</script>
 <?php exit; }
?>
<?php
 if($n==52)
 { //Editar Usuarios
     $campos = "usu_nombre|S,usu_apel|S,usu_corto|S,usu_cedula|S,usu_car_id|N,usu_emailcor|S,usu_emailper|S,usu_fijo|S,";
     $campos .= "usu_celular|S,usu_dir|S,usu_obs|S,usu_act_id|S,usu_per_id|N";
     $Gen->SetDatos($campos,"usuario","usu_id=".$_POST['id']);
     $Gen->logueado($_SESSION['usu_id'],$_SESSION['equipo'],"Modificar Usuarios");
  ?>
     <form name="frmenv" action="aplicacion.php" method="POST">
     <input type="hidden" name="n" value="5">
     <input type="hidden" name="msg" value="Usuario modificado con exito!">
     </form>
     <script>document.frmenv.submit();</script>
 <?php exit; } ?>
 <?php
    if($n==53)
    {
     $Gen->borrarusuarios($_POST['id']);
	 $Gen->logueado($_SESSION['usu_id'],$_SESSION['equipo'],"Borrar Usuarios");
     ?>
     <form name="frmenv" action="aplicacion.php" method="POST">
     <input type="hidden" name="n" value="5">
     <input type="hidden" name="msg" value="Usuario Eliminado con exito!">
     </form>
     <script>document.frmenv.submit();</script>
 <?php exit; }
 ?>
<?php
   if($n==5)
   { 
      require_once("usuarios.php");
   }
?>

<?php
   if($n==6)
   { ?>
   <div id="barra">
<a href="#" class="tramites">ESTADISTICAS</a>
<a href="logout.php"></a>
<a href="aplicacion.php?n=1" class="volver"></a>
<br class="clear" />
</div>
<div id="centro">
  <?php    echo "NO TENGO NI IDEA COMO HACERLO...ESTOY EN PROCESO CREATIVO..."; ?>
  </div>
  <?php  }
?>
<!--AQUI TERMINA-->
<!--</div><!--TERMINA DIV CENTRO-->

<div class="btn_alianza"><a href="#"><img src="tabbed_pages/grupo_alianza.png" alt="" width="150" height="54" /></a></div>
<div class="btn"><a href="#"><!--<img src="tabbed_pages/masterrobots.png" alt="" width="80" height="28" />--></a></div>


</div>
</body>
</html>
