<?
  if(isset($_POST['iddoc']) && $_POST['iddoc']>0)
  {  //echo "ENTRA";
     $d = $Tra->GetDocumento($_POST['iddoc']);
	 //print_r($d);
	 $nn = 44;
  }
  else
  {
     $nn = 433;
  }
 
?>
<script>
$(document).ready(function(){
	$("#empresadoc").change(function(){
		$.post("combos/carga_select22.php",{ id:$(this).val() },function(data){$("#sededoc").html(data);})
	});
	$("#sededoc").change(function(){
		$.post("combos/carga_select33.php",{ id:$(this).val() },function(data){$("#doc_axe_id").html(data);})
	});doc_axe_id
	$("#doc_axe_id").change(function(){
		$.post("combos/carga_selectdxd.php",{ id:$(this).val() },function(data){$("#doc_usudestinoid").html(data);})
	});
	$("#depempresa").change(function(){
		$.post("combos/carga_select5.php",{ id:$(this).val() },function(data){$("#txt_usuasig").html(data);})
	});
	
})
function validarmasdoc()
{
   if(document.formdoc.doc_tra_id.value=="")
   {
       alert("Debe ingresar o consultar un tramite para poder ingresar un documento.");
	   return false;	   
   }
   if(document.formdoc.depto_id.value==0)
   {
        alert('Debe seleccionar un Departamento del pais.');
		document.formdoc.depto_id.focus();
		return false();
   }
   if(document.formdoc.doc_ciu_id.value==0)
   {
        alert('Debe seleccionar una ciudad.');
		document.formdoc.doc_ciu_id.focus();
		return false();
   }
   if(document.formdoc.doc_txd_id.value==0)
   {
        alert('Debe seleccionar un tipo de documento.');
		document.formdoc.doc_txd_id.focus();
		return false();
   }
   if(document.formdoc.empresadoc.value==0)
   {
        alert('Debe seleccionar una Empresa.');
		document.formdoc.empresadoc.focus();
		return false();
   }
   if(document.formdoc.sededoc.value==0)
   {
        alert('Debe seleccionar una Sede de la Empresa.');
		document.formdoc.sededoc.focus();
		return false();
   }
   if(document.formdoc.doc_axe_id.value==0)
   {
        alert('Debe seleccionar un Departamento de la Sede.');
		document.formdoc.doc_axe_id.focus();
		return false();
   }
   if(document.formdoc.doc_usudestinoid.value==0 && document.formdoc.doc_usudestino.value=="")
   {
      alert("Debe seleccionar o ingresar un Destinatario.");
	  document.formdoc.doc_usudestinoid.focus();
	  return false;
   }
   if(document.formdoc.doc_txe_id.value==0)
   {
        alert("Debe seleccionar el Tipo Empresa Remitente.");
		document.formdoc.doc_txe_id.focus();
		return false;
   }
   if(document.formdoc.doc_exc_id.value==0 && document.formdoc.doc_entremitente.value=="")
   {
       alert("Debe seleccionar una empresa o ingresar el nombre de la Entidad Remitente.");
	   document.formdoc.doc_exc_id.focus();
	   return false;
   }
   if(document.formdoc.doc_remitente.value=="")
   {
       alert("Debe ingresar el nombre del Remitente.");
	   document.formdoc.doc_remitente.focus();
	   return false;
   }
   if(document.formdoc.doc_fecdoc.value=="")
   {
       alert("Debe ingresar la fecha impresa en el documento.");
	   document.formdoc.doc_fecdoc.focus();
	   return false;
   }
   if(document.formdoc.doc_asunto.value=="")
   {
       alert("Debe ingresar el asunto del documento.");
	   document.formdoc.doc_asunto.focus();
	   return false;
   }
   else
   {
      document.formdoc.submit();
	  return true;
   }
}
</script>
<div id="loginPan_vtres">
<form name="formdoc" action="" method="post">
<div class="cabecera"></div>
      <table border="0" cellspacing="0" cellpadding="0" align="center">
      
      <tr>
    <td width="130"><label>Consecutivo:</label></td>
    <td width="776"><b><font color="#454545"><?php if(isset($_SESSION['consecutivo']) && $_SESSION['consecutivo']!='') echo $_SESSION['consecutivo']; else echo "";?></font></b></td>
  </tr>
  <tr>
    <td><label>Departamento (Pa&iacute;s)</label></td>
    <td><?php $PSql = "SELECT dep_id,dep_nombre FROM $t_departamento WHERE dep_estado=1;";
	    echo $Gen->ComboBox($PSql,"dep_id","dep_nombre","depto_id",$_SESSION['departamento'],"onchange='doc_ciu_idcambia(this);ocultar(this)'"); ?></select></td>
  </tr>
  <tr>
    <td><label>Ciudad</label></td>
    <td><?php  if(isset($_SESSION['ciudad']) && $_SESSION['ciudad']>0)
	              $PSql = "SELECT ciu_id,ciu_nombre FROM $t_ciudad WHERE ciu_estado=1 ORDER BY ciu_nombre;";
			   else
	              $PSql = "SELECT ciu_id,ciu_nombre FROM $t_ciudad WHERE 1=2 AND ciu_estado=1 ORDER BY ciu_nombre;";
	    echo $Gen->ComboBox($PSql, "ciu_id","ciu_nombre","doc_ciu_id",$_SESSION['ciudad']); ?>
		<?php $Gen->Sincronice2Combos("depto_id","doc_ciu_id","ciudad",0,"ciu_dep_id","ciu_id","ciu_nombre");?></td>
  </tr>
   <tr>
    <td><label>Tipo Documento <?=$Tra->tooltip("tipodoc");?></label></td>
    <td><?php $PSql = "SELECT txd_id,txd_nombre FROM $t_tipo_documento WHERE txd_estado=1;";
	               echo $Gen->ComboBox($PSql, txd_id,txd_nombre,doc_txd_id,$d[2]); ?></td>
  </tr>
    
  <tr>
    <td><label>Empresa Propia <?=$Tra->tooltip("empresalianza");?></label></td>
    <td><?php $PSql = "SELECT exa_id,exa_nombre FROM alianza_emp WHERE exa_estado=1 ORDER BY exa_nombre;";
	    echo $Gen->ComboBox($PSql,"exa_id","exa_nombre","empresadoc",$d[3]); ?></td>
  </tr>
  <tr>
    <td><label>Sede Empresa Propia <?=$Tra->tooltip("sedealianza");?></label></td>
    <td><select name="sededoc" id="sededoc" onkeypress="return handleEnter(this, event)">
        <option selected value="<?if($d[4]>0) echo $d[4]; else echo 0;?>"><?=$Tra->seleccione($d[14])?></option>
	</select></td>
  </tr>
  <tr>
    <td><label>Depto Empresa Propia <?=$Tra->tooltip("deptoalianza");?></label></td>
    <td><select name="doc_axe_id" id="doc_axe_id" onkeypress="return handleEnter(this, event)" required>
        <option selected value="<?if($d[5]>0) echo $d[5]; else echo 0;?>"><?=$Tra->seleccione($d[15])?></option>
	</select></td>
  </tr>
  
  <tr>
    <td><label>Destinatario <?=$Tra->tooltip("destinatarioid");?></label></td> 
    <td><select name="doc_usudestinoid" id="doc_usudestinoid" onkeypress="return handleEnter(this, event)" required>
        <option selected value="<?if($d[6]>0) echo $d[6]; else echo 0;?>"><?=$Tra->seleccione($d[19])?></option>
	</select></td>
  </tr>
  <tr>
    <td width="213"><label>Nombre Destinatario <?=$Tra->tooltip("destinatario");?></label></td>
    <td width="351"><input type="text" name="doc_usudestino" value="<?=$d[7]?>"></td>
  </tr>
  <tr>
    <td><label> Tipo Empresa </label></td>
    <td><?php $PSql = "SELECT txe_id,txe_nombre FROM $t_tipo_empresacliente WHERE txe_ext_id<>4 AND txe_estado=1 ORDER BY txe_nombre;";
	     echo $Gen->ComboBox($PSql,"txe_id","txe_nombre","doc_txe_id",$d[20],"onchange='doc_exc_idcambia(this);ocultar(this)'"); ?></td>
  </tr>
  <tr>
    <td><label>Empresa </label></td>
    <td><?php if($_POST['iddoc']>0)
	             $PSqlc = "SELECT exc_id,exc_nombre FROM $t_empresa_cliente WHERE exc_estado=1 ORDER BY exc_nombre;";
			  else
			     $PSqlc = "SELECT exc_id,exc_nombre FROM $t_empresa_cliente WHERE 1=2 AND exc_estado=1 ORDER BY exc_nombre;";
			  echo $Gen->ComboBox($PSqlc,"exc_id","exc_nombre","doc_exc_id",1); ?>
		<?php $Gen->Sincronice2Combos("doc_txe_id","doc_exc_id",$t_empresa_cliente,0,"exc_txe_id","exc_id","exc_nombre");?></td>
  </tr>
  <tr>
    <td><label>Entidad Remitente <?=$Tra->tooltip("entremitente");?></label></td>
    <td><input type="text" name="doc_entremitente" id="doc_entremitente" value="<?=$d[10]?>"/></td>
  </tr>
  <tr>
    <td><label>Nombre Remitente <?=$Tra->tooltip("remitente");?></label></td>
    <td><input type="text" name="doc_remitente" id="doc_remitente" value="<?=$d[11]?>"/></td>
  </tr>
 <tr>
    <td width="130"><label>Fecha Documento  <?=$Tra->tooltip("fechadoc");?></label></td>
    <td><input name="doc_fecdoc" type="text" id="dateArrival" class="test" value="<?=$d[8]?>">
        </td>
  </tr>
 <tr>
    <td><label>Asunto Documento <?=$Tra->tooltip("destinatarioid");?></label></td>
    <td>
    <textarea name="doc_asunto" id="doc_asunto" cols="45" rows="5"><?=$d[9]?></textarea></td>
  </tr>
  
  <tr>
    <td><label>Observaciones <?=$Tra->tooltip("observacion");?></label></td>
    <td>
      <textarea name="doc_obsdocmento" id="doc_obsdocmento" cols="45" rows="5"><?=$d[13]?></textarea></td>
  </tr>
   <tr>
    <td><label>Informaci&oacute;n Anexos <?=$Tra->tooltip("anexos");?></label></td>
    <td><textarea name="doc_anexos" id="doc_anexos" cols="45" rows="5"><?=$d[12]?></textarea></td>
  </tr>
  
  <tr>
    <td colspan="2">&nbsp;</td>
    </tr>
</table>
<input name="enviar" type="button" class="button" value="Guardar" onclick="validarmasdoc();" />
<input name="resetdoc" type="reset" class="button" value="Limpiar" />
<input type="hidden" name="n" value="<?=$nn?>">
<input type="hidden" name="doc_tra_id" value="<?=$Tra->idtramite($_SESSION['consecutivo'])?>">
<input type="hidden" name="doc_equipo" value="<?=$Gen->nombreequipo()?>">
<input type="hidden" name="doc_usu_id" value="<?=$_SESSION['usu_id']?>">
<input type="hidden" name="iddocu" value="<?=$_POST['iddoc']?>">
<input type="hidden" name="tra_consecutivo" value="<?=$_SESSION['consecutivo']?>">
</form>
 <br class="clear" /></div>