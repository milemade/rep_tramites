<?php
//Binario a Decimal
echo "LUN sab".bindec('001010') . "<br>";
echo "LUN MAR".bindec('110000') . "<br>";
echo "LUN MAR MIER".bindec('101000') . "<br>";
echo "LUN MAR MIER JUE".bindec('111100') . "<br>";
echo "LUN MAR MIER JUE VIE".bindec('111110') . "<br>";
echo "SAB".bindec('111111') . "<br>";

echo bindec('111');
//decimal a Binario
echo decbin(12) . "\n";
echo decbin(26);

?>