<style type="text/css">
<!--

-->
</style>
<table width="411" border="0">
  <tr>
    <td width="151"><form id="form1" name="form1" method="post" action="">
      <label>
        <input class="texcon" type="text" name="textfield" id="textfield" />
        </label> 
    </form>    </td>
    <td width="123"><label>
      <select name="select" id="select" class="texcon">
        <option>SELECCIONE</option>
        <option>NOMBRE TRAMITE</option>
        <option>CONSECUTIVO</option>
        <option>EMPRESA</option>
        <option>DIAS ATRASO TAREA</option>
        <option>DIAS ATRASO ACUMULADO</option>
      </select>
    </label></td>
    <td width="123"><input type="submit"  class="bot" name="button" id="button" value="&nbsp;&nbsp;&nbsp;Buscar" /></td>
  </tr>
</table>
<form action="" method="get">
<table width="928" border="0">
<tr>
    <td colspan="12"><table width="900" border="0">
  <tr>
    <td class="texcon" width="169"><input type="checkbox" name="checkbox2" id="checkbox2" />&nbsp;&nbsp;<b>Seleccionar Todo</b></td>
    <td width="611"><input name="" type="button" class="botonmist" value="Ver m&aacute;s tarde"/></td>
	<td width="106"><input type="button" name="imprimir" value="&nbsp;&nbsp;&nbsp;&nbsp;Imprimir"  class="bot" onClick="window.print();"/>
</td>
  </tr>
</table></td>
  </tr>
  <tr>
    <td width="20" class="tit">&nbsp;</td>
    <td width="73" class="tit"><div align="center">Fecha Inicio AAAA-MM-DD</div></td>
    <td width="113" class="tit"><div align="center">Consecutivo</div></td>
    <td width="109" class="tit"><div align="center">Empresa</div></td>
    <td width="125" class="tit"><div align="center">Nombre Tr&aacute;mite</div></td>
    <td width="72" class="tit"> <div align="center">Fecha Vence AAAA-MM-DD</div></td>
    <td width="37" class="tit"><div align="center">Atraso Tarea (Dias)</div></td>
    <td width="109" class="tit"><div align="center">Tarea</div></td>
    <td width="58" class="tit"><div align="center">Atraso Acumulado (Dias)</div></td>
    <td colspan="3" class="tit">&nbsp;</td>
  </tr>
  <tr bgcolor="#fff">
    <td><input type="checkbox" name="checkbox" id="checkbox" /></td>
    <td class="texcon">2012-09-15</td>
    <td class="texcon">crtgf201224000</td>
    <td class="texcon">Constructora alianza porve</td>
    <td class="texcon">requerimiento dian-567890</td>
    <td class="texcon">2012-09-23</td>
    <td class="texcon"><div align="center">0</div></td>
    <td class="texcon">radicar cuenta cobro eps</td>
    <td class="texcon"><div align="center">5</div></td>
    <td width="44"><div align="center"><input type="button" value="Ver" class="botonmist"></div></td>
    <td width="80"><div align="center"><input type="button" value="Prorrogar" class="botonmist"></div></td>
    <td width="72"><div align="center"><input type="button" value="Finalizar" class="botonmist"></div></td>
  </tr>
  <tr bgcolor="#6487C8"> 
    <td><input type="checkbox" name="checkbox" id="checkbox" /></td>
    <td class="texcon">2012-09-15</td>
    <td class="texcon">crtgf201224000</td>
    <td class="texcon">Constructora alianza porve</td>
    <td class="texcon">requerimiento dian-567890</td>
    <td class="texcon">2012-09-23</td>
    <td class="texcon"><div align="center">0</div></td>
    <td class="texcon">radicar cuenta cobro eps</td>
    <td class="texcon"><div align="center">5</div></td>
    <td width="44"><div align="center"><input type="button" value="Ver" class="botonmist"></div></td>
    <td width="80"><div align="center"><input type="button" value="Prorrogar" class="botonmist"></div></td>
    <td width="72"><div align="center"><input type="button" value="Finalizar" class="botonmist"></div></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
</table>
</form> 