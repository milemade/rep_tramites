<div id="centro">
<div id="loginPan_vtresss">
<div class="cabecera">Ingrese el E.mail.</div>
<form name="frm" action="aplicacion.php" method="post">
<table  border="0" cellspacing="0" cellpadding="0">
<tr>
    <td><label>E.mail:</label></td>
    <td><input name="email" type="text"/></select></td>
  </tr>
</table>
<input name="limpiar" type="reset" class="button" value="Limpiar" />
<input name="enviar" type="button" class="button" value="Enviar" onclick="validar();"/>		
<br class="clear" />
<input type="hidden" name="n" value="121">
</form>
</div>



      <table width="750" border="0" cellspacing="0" cellpadding="0" align="center">
      
      <tr>
    <td width="93"><label>Consecutivo Tr&aacute;mite:</label></td>
    <td width="187"><input name="consevutivo" type="text" value="20124000001" readonly/></select></td>
  </tr>
  <tr>
    <td> <label>Observaciones:</label></td>
    <td><textarea></textarea></td>
  </tr>
  <tr>
    <td colspan="2">&nbsp;</td>
    </tr>
</table>
<input name="Input" type="submit" class="button" value="Enviar">

 <script> function cambiarDisplay(id) {
  if (!document.getElementById) return false;
  fila = document.getElementById(id);
  if (fila.style.display != "none") {
    fila.style.display = "none"; //ocultar fila
  } else {
    fila.style.display = ""; //mostrar fila
  }
} </script>
  
<table border="0" width="100%">
      
      <tr class="celda_izq" id="row1" onClick="cambiarDisplay('row2')">
	   <td> mayo 02 2012</td>
        <td>Empresa 1 - Auxiliar Fulano</td>
        <td><img src="imagenes/plus_sign.png" width="8" height="8" /></td>
      </tr>
	   <tr class="celda_izq" id="row2" onClick="cambiarDisplay('row2')" style="display:none">
        <td colspan="3">carreta Fulano cargo 1</td>
      </tr>
	  
	  <tr class="celda_izq_azul" id="row3" onClick="cambiarDisplay('row4')">
	   <td width="110"> mayo 03 2012</td>
        <td>Empresa 1 - Auxiliarr Sutano</td>
        <td><img src="imagenes/plus_sign.png" width="8" height="8" /></td>
      </tr>
	   <tr class="celda_izq_azul" id="row4" onClick="cambiarDisplay('row4')" style="display:none">
        <td colspan="3">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum quis purus nisl. Aliquam erat volutpat. Phasellus vel volutpat neque. Suspendisse hendrerit commodo dapibus. Nam et felis eget nunc pulvinar accumsan. Pellentesque porta faucibus lacus. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae.</td>
      </tr>
      
    </table>
	</div>