<?php
             echo $max = "CON201200400";
			 echo "<br>";
			 echo $cedenamax = substr($max,9);
			 echo "<br>";
			 echo $cedenamax0 = substr($max,0,9);
			 echo "<br>";
			 $maximo = (int)$cedenamax + 1;
			 $consecutivo = $cedenamax0.$maximo;
			 echo $consecutivo;
?>