<form name="frm" method="post" action="aplicacion.php">
<?php if(isset($_GET['n']) && $_GET['n']>0){ ?>
<input type="hidden" name="n" value="<?php echo $_GET['n'];?>">
<?php } ?>
<?php if(isset($_GET['tablaoriginal']) && $_GET['tablaoriginal']!=""){ ?>
<input type="hidden" name="tablaoriginal" value="<?php echo $_GET['tablaoriginal'];?>">
<?php } ?>
<?php if(isset($_GET['mio']) && $_GET['mio']>0){?>
<input type="hidden" name="mio" value="<?php echo $_GET['mio'];?>">
<?php } ?>
<?php if(isset($_GET['nombretabla']) && $_GET['nombretabla']!=""){?>
<input type="hidden" name="nombretabla" value="<?php echo $_GET['nombretabla'];?>">
<?php } ?>
<?php if(isset($_GET['id']) && $_GET['id']>0){?>
<input type="hidden" name="idaxm" value="<?php echo $_GET['id'];?>">
<?php } ?>
<?php if(isset($_GET['pagina']) && $_GET['pagina']>0){?>
<input type="hidden" name="pagina" value="<?php echo $_GET['pagina'];?>">
<?php } ?>
<?php if(isset($_GET['v_id']) && $_GET['v_id']>0){?>
<input type="hidden" name="v_id" value="<?php echo $_GET['v_id'];?>">
<? } ?>
<?php if(isset($_GET['descripcion']) && $_GET['descripcion']!=""){?>
<input type="hidden" name="descripcion" value="<?php echo $_GET['descripcion'];?>">
<? } ?>
<?php if(isset($_GET['campousu']) && $_GET['campousu']!=""){?>
<input type="hidden" name="campousu" value="<?php echo $_GET['campousu'];?>">
<? } ?>
<?php if(isset($_GET['campofechahora']) && $_GET['campofechahora']!=""){?>
<input type="hidden" name="campofechahora" value="<?php echo $_GET['campofechahora'];?>">
<? } ?>
<?php if(isset($_GET['submenu']) && $_GET['submenu']!=""){?>
<input type="hidden" name="submenu" value="<?php echo $_GET['submenu'];?>">
<? } ?>
<?php if(isset($_GET['camposub']) && $_GET['camposub']!=""){?>
<input type="hidden" name="camposub" value="<?php echo $_GET['camposub'];?>">
<? } ?>
<?php if(isset($_GET['tablapadre']) && $_GET['tablapadre']!=""){?>
<input type="hidden" name="tablapadre" value="<?php echo $_GET['tablapadre'];?>">
<? } ?>
<?php if(isset($_GET['idpadre']) && $_GET['idpadre']>0){ ?>
<input type="hidden" name="idpadre" value="<?php echo $_GET['idpadre'];?>">
<? } ?>
<?php if(isset($_GET['idaxmpadre']) && $_GET['idaxmpadre']!=""){ ?>
<input type="hidden" name="idaxm" value="<?php echo $_GET['idaxmpadre'];?>">
<? } ?>
<?php if(isset($_GET['submenu']) && $_GET['submenu']!=""){ ?>
<input type="hidden" name="submenu" value="<?php echo $_GET['submenu'];?>">
<? } ?>
<?php if(isset($_GET['txt_dxe_id']) && $_GET['txt_dxe_id']!=""){ ?>
<input type="hidden" name="txt_dxe_id" value="<?php echo $_GET['txt_dxe_id'];?>">
<? } ?>
<input type="hidden" name="campoequipo" value="<?=$_GET['campoequipo']?>">
<input type="hidden" name="bantra" value="<?=$_GET['ban']?>">

</form>
<script>document.frm.submit();</script>
<?php exit;?>
