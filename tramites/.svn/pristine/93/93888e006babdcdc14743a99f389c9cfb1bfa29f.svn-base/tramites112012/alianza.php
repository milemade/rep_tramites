<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml2/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>||| CENTRO DE SOLUCIONES |||</title>
<link rel="stylesheet" media="all" type="text/css" href="tabbed_pages/interna_pages.css" />
</head>
<body>

<div id="cuerpo_int">
<div class="logo"><img src="imagenes/logo_centro_int.png" alt="" width="428" height="117" class="left" />
<div id="usuario"><h2 class="txt_azul">Perengano José</h2></div>
<br class="clear" />
</div>
<div id="barra">
<a href="#"></a>
</div>

<div id="centro">
<?php require_once("pes.php");?>
<p class="texto">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum quis purus nisl. Aliquam erat volutpat. Phasellus vel volutpat neque. Suspendisse hendrerit commodo dapibus. Nam et felis eget nunc pulvinar accumsan. Pellentesque porta faucibus lacus. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae.<br />
<br />
Phasellus iaculis lorem sodales diam dignissim id tristique augue pellentesque. Fusce ut mi ac purus auctor faucibus. Mauris pulvinar pulvinar vehicula. Sed cursus lacinia nisl ac pulvinar. Sed imperdiet pretium odio eget commodo. Donec consequat ultrices mollis. Proin id iaculis ligula. Aenean felis dui, laoreet vel suscipit in, malesuada commodo massa. Fusce sit amet velit nec ligula varius pharetra ac eu libero. Aliquam erat volutpat.</p>
<br class="clear" />
</div>

<br class="clear" />
</div>

